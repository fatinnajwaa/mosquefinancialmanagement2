<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-24 00:10:10 --> Severity: Notice --> Undefined variable: action C:\xampp\htdocs\masjid\application\views\dashboard\treatment_edit.php 11
ERROR - 2021-01-24 00:16:08 --> Query error: Duplicate entry '' for key 'PRIMARY' - Invalid query: INSERT INTO `tbltreatment` (`name`, `duration`, `updatedTime`, `createdTime`) VALUES ('Kursus Mengaji Bersama Ustaz Haikal (1 Feb 2021- Feb 2021)', '5', '2021-01-24 12:16:08', '2021-01-24 12:16:08')
ERROR - 2021-01-24 00:23:10 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-24 00:23:10 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-24 00:23:10 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-24 00:29:46 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-24 00:29:46 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-24 00:29:46 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-24 07:57:16 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-24 07:57:16 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-24 07:57:16 --> 404 Page Not Found: Public/admin
