<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-02 13:37:56 --> 404 Page Not Found: Public/admin
ERROR - 2021-02-02 14:09:45 --> 404 Page Not Found: manager/Auth/login
ERROR - 2021-02-02 14:14:43 --> Severity: Notice --> Undefined variable: btnBg C:\xampp\htdocs\masjid\application\views\auth\login.php 7
ERROR - 2021-02-02 14:15:39 --> 404 Page Not Found: Public/admin
ERROR - 2021-02-02 14:15:39 --> 404 Page Not Found: Public/admin
ERROR - 2021-02-02 14:15:39 --> 404 Page Not Found: Public/admin
ERROR - 2021-02-02 14:31:02 --> Query error: Unknown column 'treatmentID' in 'order clause' - Invalid query: SELECT *
FROM `tbltreatment`
WHERE `isDelete` =0
ORDER BY `treatmentID` ASC
ERROR - 2021-02-02 14:44:03 --> Query error: Unknown column 'treatmentID' in 'order clause' - Invalid query: SELECT *
FROM `tbltreatment`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `treatmentID` DESC
ERROR - 2021-02-02 14:44:14 --> Query error: Unknown column 'treatmentID' in 'order clause' - Invalid query: SELECT *
FROM `tbltreatment`
WHERE `isDelete` =0
ORDER BY `treatmentID` ASC
ERROR - 2021-02-02 15:16:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'spadb' C:\xampp\htdocs\masjid\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-02-02 15:16:05 --> Unable to connect to the database
ERROR - 2021-02-02 15:16:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'spadb' C:\xampp\htdocs\masjid\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-02-02 15:16:07 --> Unable to connect to the database
ERROR - 2021-02-02 15:16:53 --> 404 Page Not Found: Dashboard/treatments
ERROR - 2021-02-02 15:17:03 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Invoice.php 36
ERROR - 2021-02-02 15:17:04 --> Query error: Table 'spadb.tbl_class' doesn't exist - Invalid query: SELECT *
FROM `TBL_class`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 15:30:17 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Invoice.php 36
ERROR - 2021-02-02 15:30:17 --> Query error: Table 'spadb.tbl_class' doesn't exist - Invalid query: SELECT *
FROM `TBL_class`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 15:30:25 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Invoice.php 36
ERROR - 2021-02-02 15:30:25 --> Query error: Table 'spadb.tbl_class' doesn't exist - Invalid query: SELECT *
FROM `TBL_class`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 15:30:57 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Invoice.php 36
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:30:57 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 15:30:57 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 15:30:57 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 15:30:57 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 15:31:02 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Invoice.php 36
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:31:02 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 15:31:02 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 15:31:02 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 15:31:02 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 15:32:12 --> Severity: Warning --> Use of undefined constant TBL_CLASS - assumed 'TBL_CLASS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Invoice.php 36
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:32:13 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 15:32:13 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 15:32:13 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 15:32:13 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 15:34:06 --> Severity: Warning --> Use of undefined constant TBL_CLASS - assumed 'TBL_CLASS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Invoice.php 36
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 15:34:06 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 15:34:06 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 15:34:06 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 15:34:06 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 15:37:53 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 84
ERROR - 2021-02-02 15:37:53 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 85
ERROR - 2021-02-02 15:37:53 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 86
ERROR - 2021-02-02 15:37:54 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 87
ERROR - 2021-02-02 15:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'masjidusim' C:\xampp\htdocs\masjid\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-02-02 15:40:01 --> Unable to connect to the database
ERROR - 2021-02-02 15:40:22 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 84
ERROR - 2021-02-02 15:40:22 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 85
ERROR - 2021-02-02 15:40:22 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 86
ERROR - 2021-02-02 15:40:22 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 87
ERROR - 2021-02-02 15:41:29 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 84
ERROR - 2021-02-02 15:41:29 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 85
ERROR - 2021-02-02 15:41:29 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 86
ERROR - 2021-02-02 15:41:29 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\users\customer_edit.php 87
ERROR - 2021-02-02 15:51:46 --> Severity: error --> Exception: Call to undefined method Service_model::getRemainingclass() C:\xampp\htdocs\masjid\application\views\users\customer_list.php 46
ERROR - 2021-02-02 15:53:15 --> Severity: error --> Exception: Call to undefined method Service_model::getRemainingclass() C:\xampp\htdocs\masjid\application\views\users\customer_list.php 46
ERROR - 2021-02-02 15:54:58 --> Severity: error --> Exception: Call to undefined method Service_model::getRemainingclass() C:\xampp\htdocs\masjid\application\views\users\customer_list.php 46
ERROR - 2021-02-02 15:56:44 --> Severity: error --> Exception: Call to undefined method Service_model::getRemainingclass() C:\xampp\htdocs\masjid\application\views\users\customer_list.php 46
ERROR - 2021-02-02 15:56:48 --> Severity: error --> Exception: Call to undefined method Service_model::getRemainingclass() C:\xampp\htdocs\masjid\application\views\users\customer_list.php 46
ERROR - 2021-02-02 15:57:05 --> Severity: Notice --> Undefined index: totalTreatment C:\xampp\htdocs\masjid\application\models\Service_model.php 643
ERROR - 2021-02-02 15:57:05 --> Severity: Notice --> Undefined index: totalTreatment C:\xampp\htdocs\masjid\application\models\Service_model.php 643
ERROR - 2021-02-02 16:00:23 --> Severity: error --> Exception: syntax error, unexpected ':' C:\xampp\htdocs\masjid\application\views\users\customer_list.php 56
ERROR - 2021-02-02 16:10:24 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 16:10:44 --> Severity: error --> Exception: syntax error, unexpected 'trim' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\masjid\application\controllers\Expense.php 88
ERROR - 2021-02-02 16:15:32 --> Severity: Notice --> Undefined index: tea C:\xampp\htdocs\masjid\application\controllers\Expense.php 95
ERROR - 2021-02-02 16:15:32 --> Severity: Notice --> Undefined index: tea C:\xampp\htdocs\masjid\application\controllers\Expense.php 95
ERROR - 2021-02-02 16:19:56 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:23:28 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:25:29 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:32:36 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:33:47 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:40:26 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:40:30 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:43:02 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:43:03 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:43:04 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:43:17 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:43:23 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:43:30 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:46:13 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:48:19 --> Query error: Table 'masjidusim.tblclass' doesn't exist - Invalid query: SELECT *
FROM `tblclass`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 16:49:11 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 16:49:44 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 16:49:48 --> 404 Page Not Found: Dashboard/class
ERROR - 2021-02-02 16:49:56 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 16:50:11 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 16:53:40 --> Query error: Unknown column 'productID' in 'order clause' - Invalid query: SELECT *
FROM `tblproduct`
WHERE `isDelete` =0
ORDER BY `productID` ASC
ERROR - 2021-02-02 16:56:08 --> Query error: Table 'masjidusim.tblproduct' doesn't exist - Invalid query: SELECT *
FROM `tblproduct`
WHERE `isDelete` =0
ORDER BY `productID` ASC
ERROR - 2021-02-02 16:56:30 --> Severity: Warning --> Use of undefined constant TBL_TYPE - assumed 'TBL_TYPE' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Invoice.php 37
ERROR - 2021-02-02 16:56:30 --> Query error: Table 'masjidusim.tbl_type' doesn't exist - Invalid query: SELECT *
FROM `TBL_TYPE`
WHERE `isDelete` =0
ORDER BY `typeID` ASC
ERROR - 2021-02-02 16:58:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:36 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:36 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:58:36 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 16:58:36 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 16:58:36 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 16:58:36 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 16:59:57 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 16:59:57 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 16:59:57 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 16:59:57 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:00:15 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:00:18 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:00:19 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:00:19 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:00:19 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:00:19 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:00:22 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:02:56 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:02:56 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:02:56 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:02:56 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:01 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:03:01 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:03:01 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:03:01 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:03:23 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:03:23 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:03:23 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:03:23 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:07:15 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:07:17 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:07:47 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:07:48 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:07:50 --> Query error: Table 'masjidusim.tblclasses' doesn't exist - Invalid query: SELECT *
FROM `tblclasses`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 17:08:01 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:08:05 --> Query error: Table 'masjidusim.tblclasses' doesn't exist - Invalid query: SELECT *
FROM `tblclasses`
WHERE `isActive` = 1
AND `isDelete` =0
ORDER BY `classID` DESC
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:39 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:40 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:08:40 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:08:40 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:08:40 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:08:40 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:08:42 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:09:11 --> 404 Page Not Found: Dashboard/class
ERROR - 2021-02-02 17:09:45 --> 404 Page Not Found: Dashboard/class
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:09:48 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:09:48 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:09:48 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:09:48 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:11:14 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:11:16 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:11:16 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:12:50 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:12:51 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:12:51 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:12:51 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:12:51 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:12:52 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:13:40 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:13:41 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:13:41 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:13:41 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:13:41 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:13:44 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:14:12 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:14:16 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:16 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:16 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:16 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:16 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:16 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:17 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:17 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:17 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:17 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:17 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:17 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:14:17 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:14:17 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:14:17 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:14:19 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:14:21 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:14:22 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:14:50 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:14:51 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:14:52 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:14:52 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:14:52 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:14:52 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:14:54 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:16:43 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:16:43 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:16:43 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:16:43 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:17:29 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:17:30 --> 404 Page Not Found: Treatments/index
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:31 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:17:32 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:17:32 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:17:32 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:17:33 --> 404 Page Not Found: Classs/index
ERROR - 2021-02-02 17:17:45 --> 404 Page Not Found: Classs/index
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:47 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:17:47 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:17:47 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:17:47 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:17:49 --> 404 Page Not Found: Classs/index
ERROR - 2021-02-02 17:17:56 --> 404 Page Not Found: Classs/index
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:17:58 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:17:58 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:17:58 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:17:58 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:18:36 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:18:36 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '1'
ERROR - 2021-02-02 17:18:38 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:18:38 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '1'
ERROR - 2021-02-02 17:18:39 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:18:39 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '1'
ERROR - 2021-02-02 17:18:46 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:18:46 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '1'
ERROR - 2021-02-02 17:18:51 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:18:51 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '1'
ERROR - 2021-02-02 17:18:54 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:18:54 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '6'
ERROR - 2021-02-02 17:23:40 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:23:40 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '1'
ERROR - 2021-02-02 17:25:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:42 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:43 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:44 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 17:25:45 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 17:25:45 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 17:25:45 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 17:25:45 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:25:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:25:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:25:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:24 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:25 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:40 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:41 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:45 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:46 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:47 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:48 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 25
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 26
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 31
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 32
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 40
ERROR - 2021-02-02 17:26:49 --> Severity: Notice --> Undefined index: treatmentID C:\xampp\htdocs\masjid\application\views\dashboard\class_list.php 41
ERROR - 2021-02-02 17:27:16 --> 404 Page Not Found: Classs/delete
ERROR - 2021-02-02 17:27:40 --> 404 Page Not Found: Classs/delete
ERROR - 2021-02-02 17:28:10 --> 404 Page Not Found: Classs/add
ERROR - 2021-02-02 17:28:40 --> 404 Page Not Found: Classs/add
ERROR - 2021-02-02 17:30:14 --> 404 Page Not Found: Classses/add
ERROR - 2021-02-02 17:32:15 --> 404 Page Not Found: Classses/add
ERROR - 2021-02-02 17:32:37 --> 404 Page Not Found: Classses/add
ERROR - 2021-02-02 17:32:57 --> 404 Page Not Found: Classses/add
ERROR - 2021-02-02 17:34:21 --> 404 Page Not Found: Classses/add
ERROR - 2021-02-02 17:34:23 --> 404 Page Not Found: Classses/add
ERROR - 2021-02-02 17:34:47 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:34:47 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '1'
ERROR - 2021-02-02 17:35:07 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:35:07 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '24'
ERROR - 2021-02-02 17:36:08 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:36:08 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '1'
ERROR - 2021-02-02 17:36:12 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:36:12 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '1'
ERROR - 2021-02-02 17:36:17 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 157
ERROR - 2021-02-02 17:36:17 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '24'
ERROR - 2021-02-02 17:44:41 --> Severity: Warning --> Use of undefined constant TBL_class - assumed 'TBL_class' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\controllers\Dashboard.php 159
ERROR - 2021-02-02 17:44:41 --> Query error: Table 'masjidusim.tbl_class' doesn't exist - Invalid query: UPDATE `TBL_class` SET `isDelete` = 1
WHERE `classID` = '24'
ERROR - 2021-02-02 18:04:26 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:04:26 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:04:26 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:04:26 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:04:26 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:04:26 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:09:07 --> Severity: Warning --> Use of undefined constant volunteerism - assumed 'volunteerism' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:09:07 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:09:07 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:09:07 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:11:42 --> Severity: error --> Exception: Call to undefined method Service_model::gettypeName() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 41
ERROR - 2021-02-02 18:13:48 --> Severity: error --> Exception: Call to undefined method Service_model::gettypeName() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 41
ERROR - 2021-02-02 18:16:35 --> Severity: error --> Exception: Call to undefined method Service_model::getTypeName() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 41
ERROR - 2021-02-02 18:18:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:20:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:24:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:26:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:29:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:29:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:29:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:36:03 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:03 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:03 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:36:03 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:36:03 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:36:03 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:36:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:31 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:31 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:36:31 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:36:31 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:36:31 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:36:34 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:34 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:34 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:36:34 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:36:34 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:36:34 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:36:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:35 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:36:35 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:36:35 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:36:35 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:36:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 54
ERROR - 2021-02-02 18:36:42 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:42 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:36:42 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:36:42 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:36:42 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:36:42 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:38:00 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:38:00 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:38:00 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:38:00 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:38:00 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:38:00 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:38:22 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:38:22 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:38:22 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:38:22 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:38:22 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:38:22 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:38:28 --> Severity: error --> Exception: Call to undefined method Service_model::gettypeName() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 41
ERROR - 2021-02-02 18:38:30 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:38:30 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:38:30 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:38:30 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:38:30 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:38:30 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:39:22 --> Severity: error --> Exception: Call to undefined method Service_model::gettypeName() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 41
ERROR - 2021-02-02 18:44:31 --> Severity: error --> Exception: Call to undefined method Service_model::gettypeName() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 41
ERROR - 2021-02-02 18:44:33 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:44:33 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:44:33 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:44:33 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:44:33 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:44:33 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:44:36 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:44:36 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:44:36 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:44:36 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:44:36 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:44:36 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:44:42 --> Severity: error --> Exception: Call to undefined method Service_model::gettypeName() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 41
ERROR - 2021-02-02 18:46:02 --> Severity: error --> Exception: Call to undefined method Service_model::gettypeName() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 41
ERROR - 2021-02-02 18:46:24 --> Severity: error --> Exception: Call to undefined method Service_model::getTypeName() C:\xampp\htdocs\masjid\application\views\invoice\page_list.php 41
ERROR - 2021-02-02 18:46:33 --> Severity: Warning --> Use of undefined constant TBL_PRODUCT - assumed 'TBL_PRODUCT' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\models\Service_model.php 572
ERROR - 2021-02-02 18:46:33 --> Severity: Warning --> Use of undefined constant TBL_PRODUCT - assumed 'TBL_PRODUCT' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\models\Service_model.php 573
ERROR - 2021-02-02 18:46:33 --> Query error: Table 'masjidusim.tbl_product' doesn't exist - Invalid query: SELECT `name`
FROM `TBL_PRODUCT`
WHERE `isDelete` =0
AND `TBL_PRODUCT`.`productID` IN('1')
ERROR - 2021-02-02 18:48:54 --> Severity: Warning --> Use of undefined constant TBL_type - assumed 'TBL_type' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\models\Service_model.php 573
ERROR - 2021-02-02 18:48:54 --> Query error: Table 'masjidusim.tbl_type' doesn't exist - Invalid query: SELECT `name`
FROM `TBL_type`
WHERE `isDelete` =0
AND `tbltype`.`typeID` IN('1')
ERROR - 2021-02-02 18:48:56 --> Severity: Warning --> Use of undefined constant TBL_type - assumed 'TBL_type' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\models\Service_model.php 573
ERROR - 2021-02-02 18:48:56 --> Query error: Table 'masjidusim.tbl_type' doesn't exist - Invalid query: SELECT `name`
FROM `TBL_type`
WHERE `isDelete` =0
AND `tbltype`.`typeID` IN('1')
ERROR - 2021-02-02 18:49:07 --> Severity: Warning --> Use of undefined constant TBL_type - assumed 'TBL_type' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\models\Service_model.php 573
ERROR - 2021-02-02 18:49:07 --> Query error: Table 'masjidusim.tbl_type' doesn't exist - Invalid query: SELECT `name`
FROM `TBL_type`
WHERE `isDelete` =0
AND `tbltype`.`typeID` IN('1')
ERROR - 2021-02-02 18:51:21 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:51:21 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:51:21 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:51:21 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:51:21 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:51:21 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:52:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:52:35 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:52:35 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:52:36 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:52:36 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:52:36 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:53:08 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:53:08 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:53:08 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:53:08 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:53:08 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:53:08 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:53:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:53:12 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:53:12 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:53:12 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:53:12 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:53:12 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:55:28 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:55:28 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:55:28 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:55:28 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:55:28 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:55:28 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:57:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:57:48 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 99
ERROR - 2021-02-02 18:57:48 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:57:48 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:57:48 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:57:48 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:58:39 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:58:39 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:58:39 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:58:39 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 18:59:06 --> Severity: Warning --> Use of undefined constant volunteer - assumed 'volunteer' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 123
ERROR - 2021-02-02 18:59:06 --> Severity: Warning --> Use of undefined constant donation - assumed 'donation' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 124
ERROR - 2021-02-02 18:59:06 --> Severity: Warning --> Use of undefined constant zakat - assumed 'zakat' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 125
ERROR - 2021-02-02 18:59:06 --> Severity: Warning --> Use of undefined constant renew - assumed 'renew' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\masjid\application\views\invoice\page_edit.php 126
ERROR - 2021-02-02 19:09:42 --> Query error: Unknown column 'duration' in 'field list' - Invalid query: INSERT INTO `tblinvoice` (`membershipID`, `customerName`, `customerMobile`, `payMode`, `amount`, `yslip`, `invoiceDate`, `duration`, `inTime`, `address`, `classID`, `type`, `employeeID`, `isActive`, `updatedTime`, `outTime`, `managerID`, `createdTime`) VALUES ('', 'Fatin Najwa', '0123456789', 'CASH', '100', '0001', '2021-02-02', '_4', '9:35 PM', 'Melaka', '2', '1', '1', 1, '2021-02-02 07:09:42', '05:30 AM', '1', '2021-02-02 07:09:42')
ERROR - 2021-02-02 19:11:21 --> Query error: Unknown column 'duration' in 'field list' - Invalid query: INSERT INTO `tblinvoice` (`membershipID`, `customerName`, `customerMobile`, `payMode`, `amount`, `yslip`, `invoiceDate`, `duration`, `inTime`, `address`, `classID`, `type`, `employeeID`, `isActive`, `updatedTime`, `outTime`, `managerID`, `createdTime`) VALUES ('', 'Fatin Najwa', '0123456789', 'CASH', '100', '0001', '2021-02-02', '_4', '9:35 PM', 'Melaka', '2', '1', '1', 1, '2021-02-02 07:11:21', '05:30 AM', '1', '2021-02-02 07:11:21')
ERROR - 2021-02-02 19:11:25 --> Query error: Unknown column 'duration' in 'field list' - Invalid query: INSERT INTO `tblinvoice` (`membershipID`, `customerName`, `customerMobile`, `payMode`, `amount`, `yslip`, `invoiceDate`, `duration`, `inTime`, `address`, `classID`, `type`, `employeeID`, `isActive`, `updatedTime`, `outTime`, `managerID`, `createdTime`) VALUES ('', 'Fatin Najwa', '0123456789', 'CASH', '100', '0001', '2021-02-02', '_4', '9:35 PM', 'Melaka', '2', '1', '1', 1, '2021-02-02 07:11:25', '05:30 AM', '1', '2021-02-02 07:11:25')
ERROR - 2021-02-02 19:19:03 --> Severity: error --> Exception: Call to undefined method Service_model::getProductName() C:\xampp\htdocs\masjid\application\controllers\Report.php 66
ERROR - 2021-02-02 19:22:13 --> Severity: error --> Exception: Call to undefined method Service_model::getProductName() C:\xampp\htdocs\masjid\application\controllers\Report.php 66
ERROR - 2021-02-02 19:23:20 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\controllers\Report.php 93
ERROR - 2021-02-02 19:23:27 --> Severity: Notice --> Undefined index: reason C:\xampp\htdocs\masjid\application\controllers\Report.php 93
