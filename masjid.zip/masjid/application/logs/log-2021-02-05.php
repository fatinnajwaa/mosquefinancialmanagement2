<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-05 07:03:56 --> 404 Page Not Found: Public/admin
