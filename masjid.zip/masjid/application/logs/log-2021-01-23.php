<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-23 09:02:13 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:05:30 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:05:30 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:05:30 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:06:27 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:06:27 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:06:28 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:07:47 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:07:47 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:07:47 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:07:47 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:08:06 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:08:06 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 09:08:06 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 19:43:24 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 19:43:24 --> 404 Page Not Found: Public/admin
ERROR - 2021-01-23 19:43:24 --> 404 Page Not Found: Public/admin
