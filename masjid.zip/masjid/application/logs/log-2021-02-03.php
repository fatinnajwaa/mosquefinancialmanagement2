<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-03 11:18:44 --> 404 Page Not Found: Public/admin
ERROR - 2021-02-03 11:24:52 --> 404 Page Not Found: Activity/index
ERROR - 2021-02-03 17:05:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\masjid\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-02-03 17:05:34 --> Unable to connect to the database
ERROR - 2021-02-03 17:05:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\masjid\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-02-03 17:05:59 --> Unable to connect to the database
ERROR - 2021-02-03 17:06:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\masjid\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-02-03 17:06:17 --> Unable to connect to the database
ERROR - 2021-02-03 17:06:22 --> 404 Page Not Found: Public/admin
ERROR - 2021-02-03 17:10:37 --> Severity: Notice --> Undefined index: tea C:\xampp\htdocs\masjid\application\controllers\Expense.php 95
ERROR - 2021-02-03 17:10:37 --> Severity: Notice --> Undefined index: tea C:\xampp\htdocs\masjid\application\controllers\Expense.php 95
