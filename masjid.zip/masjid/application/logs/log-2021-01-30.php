<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-30 06:26:52 --> 404 Page Not Found: Auth/login.php
ERROR - 2021-01-30 06:27:57 --> 404 Page Not Found: Public/admin
