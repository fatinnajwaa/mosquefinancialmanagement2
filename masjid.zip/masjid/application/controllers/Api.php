<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

//header('Content-Type: application/json');

class Api extends MY_Controller {
    
    public function __construct() {
        parent::__construct();
    }

    

}