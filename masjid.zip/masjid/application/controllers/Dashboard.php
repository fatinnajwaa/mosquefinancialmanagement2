<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

    public function __construct() {
        parent::__construct();
        // if (!$this->session->has_userdata('is_admin_login')) {
        //     redirect('auth/login');
        // }
        $userRole = $this->session->userdata('user_type');
        if($userRole==""){
            redirect('auth/login');
        }
    }
    
    public function index() {
        $userID = $this->session->userdata('userID');
        $userRole = $this->session->userdata('user_type');
        if($userRole==1){
            $data['totalManagerCount'] = $this->user->get_users(array('userRole' => 1,'isActive' => 1), FALSE, TRUE);
            $data['totalEmployeeCount'] = count($this->Service->get_all(TBL_EMPLOYEE,'*',array()));
            $data['totalCustomersCount'] = count($this->Service->get_all(TBL_CUSTOMER,'*',array('managerID'=>$userID)));
            $data['totalInvoiceCount'] = count($this->Service->get_all(TBL_INVOICE,'*',array('managerID'=>$userID)));
            $data['view'] = 'manager/dashboard';
            $this->renderAdmin($data);
        }else{
            $managerList = $this->user->get_users(array('userRole' => 1,'isActive' => 1));
            $data['managerList'] = $managerList;
            $data['totalManagerCount'] = count($managerList);
            $data['totalEmployeeCount'] = count($this->Service->get_all(TBL_EMPLOYEE,'*',array()));
            $data['totalCustomersCount'] = count($this->Service->get_all(TBL_CUSTOMER,'*',array()));
            $data['totalInvoiceCount'] = count($this->Service->get_all(TBL_INVOICE,'*',array()));
            $data['view'] = 'dashboard/dashboard';
            $this->renderAdmin($data);
        }
    }

    //for change password
    public function changePassword() {
        $loginuserID = $this->session->userdata('userID');
        $userdata = $this->user->get_users(array('userID' => $loginuserID), TRUE);
        if ($this->input->post('submit')) {
            $this->form_validation->set_rules('oldPassword', 'Old Password', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            $this->form_validation->set_rules('confirm_pwd', 'Confirm Password', 'trim|required|matches[password]');
            if ($this->form_validation->run() != FALSE) {
                
                if(isset($userdata['password']) && $userdata['password']==md5($this->input->post('oldPassword'))){
                    $data = array(
                        'password' => md5($this->input->post('password')),
                        'visible_pass' => $this->input->post('password')
                    );
                    $result = $this->user->change_pwd($data, $loginuserID);
                    if ($result) {
                        $this->session->set_flashdata('success_msg', $this->getNotification('pwdChangeSuc'));
                        redirect(base_url('dashboard/changePassword'));
                    }
                }else{
                    $this->session->set_flashdata('error_msg', $this->getNotification('passwordNotMatch'));
                    redirect(base_url('dashboard/changePassword'));
                }
            }
        }
        $data['view'] = 'auth/change_pwd';
        $this->renderAdmin($data);
    }
    
    public function profile() {
        $data['title'] = "Profile";
        $data['menu'] = "Profile";
        $loginuserID = $this->session->userdata('userID');
        $userRole = $this->session->userdata('user_type');
        $data['userRole'] = $userRole;
        $userdata = $this->user->get_users(array('userID' => $loginuserID), TRUE);
        $year = date('Y');
        if(isset($_GET['graphYear']) && $_GET['graphYear']!=""){
            $year = $_GET['graphYear'];
        }
        if($userRole==3){
            $data['yearIncomeJson'] = $this->user->getYearIncomeJson('',$year);
        }else{
            $data['yearIncomeJson'] = $this->user->getYearIncomeJson($loginuserID,$year);
        }
        $data['user'] = $userdata;
        if ($this->input->post('submit')) {
            $this->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->form_validation->set_rules('email', 'Email', 'trim|required');
            $this->form_validation->set_rules('mobile', 'Mobile', 'trim|required');
            if ($this->form_validation->run() != FALSE) {
                $data = array(
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                    'mobile' => $this->input->post('mobile'),
                    'branch' => isset($_POST['branch'])?$this->input->post('branch'):"",
                    'dob' => isset($_POST['dob'])?$this->input->post('dob'):"",
                    'address' => isset($_POST['address'])?$this->input->post('address'):"",
                );
                
                $admin_data = array('name'=>$this->input->post('name'));
                $this->session->set_userdata($admin_data);
                $result = $this->user->change_pwd($data, $loginuserID);
                if ($result) {
                    $this->session->set_flashdata('success_msg', $this->getNotification('recUpSuc'));
                    redirect(base_url('dashboard/profile'));
                }
            }
        }
        $data['view'] = 'dashboard/profile';
        $this->renderAdmin($data);
    }

    public function class() {
        $data['title'] = "class";
        $data['menu'] = "class";
        $data['resultList'] = $this->Service->get_all(TBL_CLASS,'*',array(),'classID','ASC');
        $data['view'] = 'dashboard/class_list';
        $this->renderAdmin($data);
    }
    
    public function addclass($id="") {
        $data['title'] = "Add class";
        $data['menu'] = "add class";
        if($id!=""){
            $data['title'] = "Edit class";
            $data['menu'] = "edit class";
            $rowData = $this->Service->get_row(TBL_CLASS,'*', array('classID'=>$id));
            $data['rowData'] = $rowData;
        }
        if ($this->input->post('submit')) {
            $this->form_validation->set_rules('name', 'Full name', 'required');
			$this->form_validation->set_rules('startdate', 'Start date', 'required');
			$this->form_validation->set_rules('enddate', 'End date', 'required');
            $this->form_validation->set_rules('duration', 'duration', 'trim|required');
            if ($this->form_validation->run() != FALSE) {
                $saveData = array(
                    'name' => $this->input->post('name'),
					'startdate' => $this->input->post('startdate'),
					'enddate' => $this->input->post('enddate'),
                    'duration' => $this->input->post('duration'),
                    'updatedTime' => date("Y-m-d h:i:s")
                );
                if($id!=""){
                    $this->Service->update_row(TBL_CLASS,$saveData, array('classID'=>$id));
                    $this->session->set_flashdata('success_msg', $this->getNotification('recUpSuc'));
                    redirect(base_url('class'));
                }else{
                    $saveData['createdTime'] = date("Y-m-d h:i:s");
                    $this->Service->insert_row(TBL_CLASS,$saveData);
                    $this->session->set_flashdata('success_msg', $this->getNotification('recAddSuc'));
                    redirect(base_url('class'));
                }
            }
        }
        $data['view'] = 'dashboard/class_edit';
        $this->renderAdmin($data);
    }
    
    public function deleteclass($id = 0) {
        $classid = $this->input->post('classid');
        $result = $this->Service->set_delete(TBL_CLASS,array('classID'=>$classid));
        if(!empty($result)){ echo 1; }else{ echo 0; }
    }

    public function classIsactive() {
        $classid = $this->input->post('classid');
        $status = $this->input->post('status');
        if($this->Service->update_row(TBL_class,array('isActive'=> $status), array('classID'=>$classid))){ echo '1'; }else{ echo '0';}
    }

    public function searchUserData(){
        $mobile = $this->input->post('mobile');
        $uu = $this->Service->searchClientData($mobile);
        echo '<pre>'; print_r($uu);die;
    }



}
?>

