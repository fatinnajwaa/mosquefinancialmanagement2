<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Expense extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $userRole = $this->session->userdata('user_type');
        if($userRole==""){
            redirect('auth/login');
        }
    }

    public function setExpense() {
        $data['title'] = "Expense Value";
        $data['menu'] = "expense value";
        $data['submenu'] = "Expense";
        $loginUserID = $this->session->userdata('userID');
        $resultList= $this->Service->get_row(TBL_EXPENSE_VALUE,'*');
        $data['resultList'] = $resultList;
        if(!empty($_POST['submit'])){
            $this->form_validation->set_rules('pdm', 'Pdm price', 'trim|required');
			$this->form_validation->set_rules('plm', 'plm price', 'trim|required');
            $this->form_validation->set_rules('pt', 'pt price', 'trim|required');
            $this->form_validation->set_rules('karpet', 'karpet price', 'trim|required');
            $this->form_validation->set_rules('telekung', 'telekung  price', 'trim|required');
            $this->form_validation->set_rules('sanitizer', 'sanitizer  price', 'trim|required');
            $this->form_validation->set_rules('sejadah', 'sejadah price', 'trim|required');
            $this->form_validation->set_rules('langsir', 'langsir  price', 'trim|required');
            if ($this->form_validation->run() != FALSE) {
                $data = array(
                    'managerID' => $loginUserID,
                    'pdm' => $this->input->post('pdm'),
					'plm' => $this->input->post('plm'),
                    'pt' => $this->input->post('pt'),
                    'karpet' => $this->input->post('karpet'),
                    'telekung' => $this->input->post('telekung'),
                    'sanitizer' => $this->input->post('sanitizer'),
                    'sejadah' => $this->input->post('sejadah'),
                    'langsir' => $this->input->post('langsir'), 
                    // 'isActive' => $this->input->post('isActive'),
                );
                $data['updatedTime'] = date("Y-m-d h:i:s");
                $this->Service->update_row(TBL_EXPENSE_VALUE,$data, array('expID'=>$resultList['expID']));
                $this->session->set_flashdata('success_msg', $this->getNotification('recUpSuc'));
            }
        }
        $data['view'] = 'expense/setexpense_edit';
        $this->renderAdmin($data);
    }

    public function general(){
        $data['title'] = "General Expense";
        $data['menu'] = "General Expense";
        $data['submenu'] = "Expense";
        $loginUserID = $this->session->userdata('userID');
        
        $userRole = $this->session->userdata('user_type');
        if($userRole == 3){
            $resultList= $this->Service->get_all(TBL_GENERAL_EXPENSE,'*',[],'date','DESC');
        }else{
            $resultList= $this->Service->get_all(TBL_GENERAL_EXPENSE,'*',array('managerID'=>$loginUserID),'date');
        }
        $data['resultList'] = $resultList;
        $data['view'] = 'expense/general_list';
        $this->renderAdmin($data);
    }

    public function general_edit($id=""){
        $data['title'] = "General Expense";
        $data['menu'] = "General Expense";
        $data['submenu'] = "Expense";
        $loginUserID = $this->session->userdata('userID');
        if($id!=""){
            // $data['generalList'] = $this->Service->get_all(TBL_GENERAL_EXPENSE,'*',array('genExpID'=>'0'));
            $data['title'] = "Edit General Expense";
            $data['menu'] = "Edit General Expense";
            $rowData = $this->Service->get_row(TBL_GENERAL_EXPENSE,'*',array('genExpID'=>$id));
            if(empty($rowData)){
                redirect(base_url('expense/general'));
            }
            $data['rowData'] = $rowData;
        }
        if(!empty($_POST['submit'])){
            $this->form_validation->set_rules('date', 'Date', 'trim|required');
            $this->form_validation->set_rules('pdm', 'Pembersihan Dalam Masjid/Surau', 'trim|required');
            $this->form_validation->set_rules('plm', 'Pembersihan Luar Masjid/Surau', 'trim|required');
            $this->form_validation->set_rules('pt', 'Pembersihan Tandas', 'trim|required');
            if ($this->form_validation->run() != FALSE) {
                $expanseValData= $this->Service->get_row(TBL_EXPENSE_VALUE,'*');
                $pdm = $this->input->post('pdm');
                $plm = $this->input->post('plm');
                $pt = $this->input->post('pt');
                $total = ($pdm * $expanseValData['tea']) + ($plm * $expanseValData['tea']) + ($pt * $expanseValData['pt']);
                
                $data = array(
                    'managerID' => $loginUserID,
                    'date' => date('Y-m-d',strtotime($this->input->post('date'))),
                    'pdm' => $pdm,
                    'plm' => $plm,
                    'pt' => $pt,
                    'total' => $total,
                );
                if($id!=""){
                    $data['updatedTime'] = date("Y-m-d h:i:s");
                    $this->Service->update_row(TBL_GENERAL_EXPENSE,$data, array('genExpID'=>$id));
                    $this->session->set_flashdata('success_msg', $this->getNotification('recUpSuc'));
                }else{
                    $data['createdTime'] = date("Y-m-d h:i:s");
                    $data['updatedTime'] = date("Y-m-d h:i:s");
                    $result = $this->Service->insert_row(TBL_GENERAL_EXPENSE,$data);
                    $this->session->set_flashdata('success_msg', $this->getNotification('recAddSuc'));
                }
                redirect(base_url('expense/general'));
            }
        }
        $data['view'] = 'expense/general_edit';
        $this->renderAdmin($data);
    }

    public function laundry(){
        $data['title'] = "Laundry Expense";
        $data['menu'] = "Laundry Expense";
        $data['submenu'] = "Expense";
        $loginUserID = $this->session->userdata('userID');
        $data['expValue'] = $this->Service->get_row(TBL_EXPENSE_VALUE,'*');
        $userRole = $this->session->userdata('user_type');
        if($userRole == 3){
            $resultList= $this->Service->get_all(TBL_LAUNDRY_EXPENSE,'*',[]);
        }else{
            $resultList= $this->Service->get_all(TBL_LAUNDRY_EXPENSE,'*',array('managerID'=>$loginUserID));
        }
        $data['resultList'] = $resultList;
        $data['view'] = 'expense/laundry_list';
        $this->renderAdmin($data);
    }

    public function laundry_edit($id=""){
        $data['title'] = "Laundry Expense";
        $data['menu'] = "Laundry Expense";
        $data['submenu'] = "Expense";
        $loginUserID = $this->session->userdata('userID');
        if($id!=""){
            // $data['generalList'] = $this->Service->get_all(TBL_GENERAL_EXPENSE,'*',array('genExpID'=>'0'));
            $data['title'] = "Edit Laundry Expense";
            $data['menu'] = "Edit Laundry Expense";
            $rowData = $this->Service->get_row(TBL_LAUNDRY_EXPENSE,'*',array('expenseID'=>$id));
            if(empty($rowData)){
                redirect(base_url('expense/laundry'));
            }
            $data['rowData'] = $rowData;
        }
        if(!empty($_POST['submit'])){
            $this->form_validation->set_rules('date', 'Date', 'trim|required');
            $this->form_validation->set_rules('karpet', 'karpet', 'trim|required');
            $this->form_validation->set_rules('telekung', 'telekung', 'trim|required');
            $this->form_validation->set_rules('sanitizer', 'sanitizer', 'trim|required');
            $this->form_validation->set_rules('sejadah', 'sejadah', 'trim|required');
            $this->form_validation->set_rules('langsir', 'langsir', 'trim|required');
            if ($this->form_validation->run() != FALSE) {
                $expanseValData= $this->Service->get_row(TBL_EXPENSE_VALUE,'*');
                $karpet = $this->input->post('karpet');
                $telekung = $this->input->post('telekung');
                $sanitizer = $this->input->post('sanitizer');
                $sejadah = $this->input->post('sejadah');
                $langsir = $this->input->post('langsir');
                $total = ($karpet * $expanseValData['karpet']) + ($telekung * $expanseValData['telekung']) + ($sanitizer * $expanseValData['sanitizer']) + ($sejadah * $expanseValData['sejadah']) + ($langsir * $expanseValData['langsir']);
                
                $data = array(
                    'date' => date('Y-m-d',strtotime($this->input->post('date'))),
                    'managerID' => $loginUserID,
                    'karpet' => $karpet,
                    'telekung' => $telekung,
                    'sanitizer' => $sanitizer,
                    'sejadah' => $sejadah,
                    'langsir' => $langsir,
                    'total' => $total,
                );
                if($id!=""){
                    $data['updatedTime'] = date("Y-m-d h:i:s");
                    $this->Service->update_row(TBL_LAUNDRY_EXPENSE,$data, array('expenseID'=>$id));
                    $this->session->set_flashdata('success_msg', $this->getNotification('recUpSuc'));
                }else{
                    $data['createdTime'] = date("Y-m-d h:i:s");
                    $data['updatedTime'] = date("Y-m-d h:i:s");
                    $result = $this->Service->insert_row(TBL_LAUNDRY_EXPENSE,$data);
                    $this->session->set_flashdata('success_msg', $this->getNotification('recAddSuc'));
                }
                redirect(base_url('expense/laundry'));
            }
        }
        $data['view'] = 'expense/laundry_edit';
        $this->renderAdmin($data);
    }
    
    public function laundry_delete($id = 0) {
        $id = $this->input->post('expid');
        $data = $this->Service->set_delete(TBL_LAUNDRY_EXPENSE,array('expenseID'=>$id));
        if(!empty($data)){ echo 1;}else{ echo 0;};
    }

    public function general_delete($id = 0) {
        $id = $this->input->post('expid');
        $data = $this->Service->set_delete(TBL_GENERAL_EXPENSE,array('genExpID'=>$id));
        if(!empty($data)){ echo 1;}else{ echo 0;};
    }

    //monthly expenses 
    public function monthlyExpense(){
        $data['title'] = "Monthly Expense";
        $data['menu'] = "Monthly Expense";
        $data['submenu'] = "Expense";
        $loginUserID = $this->session->userdata('userID');
        $userRole = $this->session->userdata('user_type');
        if($userRole == 3){
            $resultList= $this->Service->get_all(TBL_OFFICE_EXPENSE,'*',[]);
        }else{
            $resultList= $this->Service->get_all(TBL_OFFICE_EXPENSE,'*',array('managerID'=>$loginUserID));
        }
        $data['resultList'] = $resultList;
        $data['view'] = 'expense/monthlyExpense_list';
        $this->renderAdmin($data);
    }
    
    public function monthlyExpense_edit($id=""){
        $data['title'] = "Monthly Expense";
        $data['menu'] = "Monthly Expense";
        $data['submenu'] = "Expense";
        $loginUserID = $this->session->userdata('userID');
        $data['expType'] = $this->Service->get_all(TBL_EXPENSE_TYPE,'*',[]);
        if($id!=""){
            // $data['generalList'] = $this->Service->get_all(TBL_GENERAL_EXPENSE,'*',array('genExpID'=>'0'));
            $data['title'] = "Edit Monthly Expense";
            $data['menu'] = "Edit Monthly Expense";
            $rowData = $this->Service->get_row(TBL_OFFICE_EXPENSE,'*',array('expID'=>$id));
            if(empty($rowData)){
                redirect(base_url('expense/monthlyExpense'));
            }
            $data['rowData'] = $rowData;
        }
        if(!empty($_POST['submit'])){
            $this->form_validation->set_rules('expDate', 'Date', 'trim|required');
            $this->form_validation->set_rules('voucher', 'Voucher', 'trim|required');
            $this->form_validation->set_rules('type', 'Type', 'trim|required');
            $this->form_validation->set_rules('amount', 'amount', 'trim|required');
            $this->form_validation->set_rules('desc', 'Description', 'trim|required');
            if ($this->form_validation->run() != FALSE) {
                
                $data = array(
                    'managerID' => $loginUserID,
                    'expDate' => date('Y-m-d',strtotime($this->input->post('expDate'))),
                    'voucher' => $this->input->post('voucher'),
                    'type' => $this->input->post('type'),
                    'amount' => $this->input->post('amount'),
                    'desc' => $this->input->post('desc'),
                );
                if($id!=""){
                    $data['updatedTime'] = date("Y-m-d h:i:s");
                    $this->Service->update_row(TBL_OFFICE_EXPENSE,$data, array('expID'=>$id));
                    $this->session->set_flashdata('success_msg', $this->getNotification('recUpSuc'));
                }else{
                    $data['createdTime'] = date("Y-m-d h:i:s");
                    $data['updatedTime'] = date("Y-m-d h:i:s");
                    $result = $this->Service->insert_row(TBL_OFFICE_EXPENSE,$data);
                    $this->session->set_flashdata('success_msg', $this->getNotification('recAddSuc'));
                }
                redirect(base_url('expense/monthlyExpense'));
            }
        }
        $data['view'] = 'expense/monthlyExpense_edit';
        $this->renderAdmin($data);
    }

    public function monthlyExpense_delete($id = 0) {
        $id = $this->input->post('expid');
        $data = $this->Service->set_delete(TBL_OFFICE_EXPENSE,array('expID'=>$id));
        if(!empty($data)){ echo 1;}else{ echo 0;};
    }

     //Employee salary  
     public function employeeSalary(){
        $data['title'] = "Employee Salary";
        $data['menu'] = "employee salary";
        $data['submenu'] = "Expense";
        $loginUserID = $this->session->userdata('userID');
        $userRole = $this->session->userdata('user_type');
        if($userRole == 3){
            $resultList= $this->Service->get_all(TBL_EMPLOYEE_SALARY,'*',[]);
        }else{
            $resultList= $this->Service->get_all(TBL_EMPLOYEE_SALARY,'*',array('managerID'=>$loginUserID));
        }
        $data['resultList'] = $resultList;
        $data['view'] = 'expense/employeeSalary_list';
        $this->renderAdmin($data);
    }
    
    public function employeeSalary_edit($id=""){
        $data['title'] = "Employee Salary";
        $data['menu'] = "Employee Salary";
        $data['submenu'] = "Expense";
        $loginUserID = $this->session->userdata('userID');
        $data['employeeData'] = $this->Service->get_all(TBL_EMPLOYEE,'*',[]);
        if($id!=""){
            // $data['generalList'] = $this->Service->get_all(TBL_GENERAL_EXPENSE,'*',array('genExpID'=>'0'));
            $data['title'] = "Edit Employee Salary";
            $data['menu'] = "Edit Employee Salary";
            $rowData = $this->Service->get_row(TBL_EMPLOYEE_SALARY,'*',array('salID'=>$id));
            if(empty($rowData)){
                redirect(base_url('expense/employeeSalary'));
            }
            $data['rowData'] = $rowData;
        }
        if(!empty($_POST['submit'])){
            $this->form_validation->set_rules('employeeID', 'Employee', 'trim|required');
            $this->form_validation->set_rules('payDate', 'Date', 'trim|required');
            $this->form_validation->set_rules('voucher', 'voucher', 'trim|required');
            $this->form_validation->set_rules('salaryMonth', 'Salary Month', 'trim|required');
            $this->form_validation->set_rules('amount', 'Amount', 'trim|required');
            $this->form_validation->set_rules('desc', 'Description', 'trim|required');
            if ($this->form_validation->run() != FALSE) {
                // date('Y-m-d',strtotime($this->input->post('salaryMonth'))),
                $data = array(
                    'managerID' => $loginUserID,
                    'employeeID' => $this->input->post('employeeID'),
                    'payDate' => $this->input->post('payDate'),
                    'voucher' => $this->input->post('voucher'),
                    'salaryMonth' => $this->input->post('salaryMonth'),
                    'amount' => $this->input->post('amount'),
                    'desc' => $this->input->post('desc'),
                );
                if($id!=""){
                    $data['updatedTime'] = date("Y-m-d h:i:s");
                    $this->Service->update_row(TBL_EMPLOYEE_SALARY,$data, array('salID'=>$id));
                    $this->session->set_flashdata('success_msg', $this->getNotification('recUpSuc'));
                }else{
                    $data['createdTime'] = date("Y-m-d h:i:s");
                    $data['updatedTime'] = date("Y-m-d h:i:s");
                    $result = $this->Service->insert_row(TBL_EMPLOYEE_SALARY,$data);
                    $this->session->set_flashdata('success_msg', $this->getNotification('recAddSuc'));
                }
                redirect(base_url('expense/employeeSalary'));
            }
        }
        $data['view'] = 'expense/employeeSalary_edit';
        $this->renderAdmin($data);
    }

    public function employeeSalary_delete($id = 0) {
        $id = $this->input->post('expid');
        $data = $this->Service->set_delete(TBL_EMPLOYEE_SALARY,array('salID'=>$id));
        if(!empty($data)){ echo 1;}else{ echo 0;};
    }
    
}
?>

