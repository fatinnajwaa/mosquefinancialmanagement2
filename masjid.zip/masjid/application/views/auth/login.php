<!DOCTYPE html>
<html lang="en" style="">



<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url() ?>public/admin/assets/images/favicon.png">
    <title>Login | <?php echo $this->config->item('site_title'); ?></title>
    <!-- Bootstrap Core CSS -->
    <link href="<?= base_url() ?>public/admin/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?= base_url() ?>public/admin/css/style.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="<?= base_url() ?>public/admin/css/colors/blue.css" id="theme" rel="stylesheet">
    <link href="<?php echo $this->config->item('admin_path'); ?>css/custom.css" rel="stylesheet">

</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <section id="wrapper">
        <?php  /* background-image:url('<?php echo $this->config->item('admin_path').'assets/images/login-bg.png'; ?>'); */ ?>
        <div class="login-register " id="login"style="background-image:url('<?php echo $this->config->item('admin_path') . 'assets/images/background/slide-background-4.jpg'; ?>');padding-top: 50
px;">
        <!-- <div class="login-register" id="login"style="background-image: linear-gradient(to left bottom, #14274a, #14274a, #14274a, #14274a, #14274a);"> -->
            
            <div class="login-box card">
                <div class="card-body">
                    <?php echo form_open(base_url('auth/login'), 'class="login-form"'); ?>
                    <div class="text-center">
                        <img src="<?php echo $this->config->item('admin_path') . 'assets/images/LOGO-2xl.jpg'; ?>" width="150" />
                        <!-- <h3 class="box-title m-b-20">Admin Sign In</h3> -->
                    </div>
                    
                    <?php if (isset($msg) || validation_errors() !== '') : ?>
                    <div class="alert alert-warning alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                        <?= validation_errors(); ?>
                        <?= isset($msg) ? $msg : ''; ?>
                    </div>
                    <?php endif; ?>

                    <div class="form-group ">
                        <div class="col-xs-12">
                            <input class="form-control" type="email" name="email" id="email" required="" placeholder="Email"> </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control" type="password" name="password" id="password" required="" placeholder="Password"> </div>
                    </div>
                    <?php  /* <!-- <div class="form-group">
                            <div class="d-flex no-block align-items-center">
                                <div class="checkbox checkbox-primary p-t-0">
                                    <input id="checkbox-signup" type="checkbox">
                                    <label for="checkbox-signup"> Remember me </label>
                                </div> 
                                <div class="ml-auto">
                                    <a href="javascript:void(0)" id="to-recover" class="text-muted"><i class="fa fa-lock m-r-5"></i> Forgot pwd?</a> 
                                </div>
                            </div>
                        </div> --> */ ?>
                    <?php
                    $btnBg = $this->config->item('admin_path').'assets/images/btn_2.png';
                    ?>
                    <style>
                    .loginBgBtn {
                    height: 50px;
                    width: 100%;  
                    background-image:url('<?php echo $btnBg; ?>');
                    background-repeat:no-repeat;
                    background-size: cover;
                    background-position: center;
                    color: #fff;
                    font-weight: bolder;
                    }
                    </style>
                    <div class="form-group text-center m-t-20">
                        <div class="col-xs-12">
                            <button type="submit" name="submit" id="submit" class="btn btn-info  text-uppercase waves-effect waves-light " value="Submit">Admin Log In </button>
                        </div>
                    </div>
                    <?php  /* <!-- <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12 m-t-10 text-center">
                                <div class="social">
                                    <button class="btn btn-facebook" data-toggle="tooltip" title="Login with Facebook"> <i aria-hidden="true" class="fab fa-facebook-f"></i> </button>
                                    <button class="btn btn-googleplus" data-toggle="tooltip" title="Login with Google"> <i aria-hidden="true" class="fab fa-google-plus-g"></i> </button>
                                </div>
                            </div>
                        </div>-->
                        <!-- <div class="form-group m-b-0">
                            <div class="col-sm-12 text-center">
                                Don't have an account? <a href="pages-register.html" class="text-info m-l-5"><b>Sign Up</b></a>
                            </div>
                        </div>--> */ ?>
                    <?php echo form_close(); ?>
                    <form class="form-horizontal" id="recoverform" action="#">
                        <div class="form-group ">
                            <div class="col-xs-12">
                                <h3>Recover Password</h3>
                                <p class="text-muted">Enter your Email and instructions will be sent to you! </p>
                            </div>
                        </div>
                        <div class="form-group ">
                            <div class="col-xs-12">
                                <input class="form-control" type="text" required="" placeholder="Email"> </div>
                        </div>
                        <div class="form-group text-center m-t-20">
                            <div class="col-xs-12">
                                <button class="btn btn-primary btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Reset</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?= base_url() ?>public/admin/assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?= base_url() ?>public/admin/assets/plugins/popper/popper.min.js"></script>
    <script src="<?= base_url() ?>public/admin/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?= base_url() ?>public/admin/js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="<?= base_url() ?>public/admin/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?= base_url() ?>public/admin/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="<?= base_url() ?>public/admin/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="<?= base_url() ?>public/admin/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="<?= base_url() ?>public/admin/js/custom.min.js"></script>
    <!-- ============================================================== -->
    <!-- Style switcher -->
    <!-- ============================================================== -->
    <!--<script src="<?= base_url() ?>public/admin/assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>-->

</body>


<!-- Mirrored from wrappixel.com/demos/admin-templates/material-pro/material/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 05:38:44 GMT -->

</html> 