<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body bg-info">
                    <h4 class="text-white card-title"> Activity Form </h4>
                </div>
                <div class="card-body">
                    <div class="box-body my-form-body">
                        <?php
                        $action = base_url('class/add');
                        if (isset($rowData['classID']) && $rowData['classID'] != "") {
                            $action = base_url('class/edit/' . $rowData['classID']);
                        } ?>
                        <form class="row" action="<?php echo $action; ?>" class="" method="post" enctype="multipart/form-data">
						
						<div class="col-sm-4 form-group">
                                    <label for="startdate" class="control-label">Start Date</label>
                                    <input type="text" name="startdate" class="form-control datePicker" placeholder="" id="startdate" value="<?php if (isset($user['startdate'])) { echo $user['startdate']; } ?>" />
                                </div>
								<div class="col-sm-4 form-group">
                                    <label for="enddate" class="control-label">End Date</label>
                                    <input type="text" name="enddate" class="form-control datePicker" placeholder="" id="enddate" value="<?php if (isset($user['enddate'])) { echo $user['enddate']; } ?>" />
                                </div>
                            <div class="col-sm-4 form-group">
                                <label for="name" class=" control-label">Activity Name</label>
                                <input type="text" name="name" value="<?php if (isset($rowData['name'])) { echo $rowData['name'];}else{ echo set_value('name'); } ?>" class="form-control form-control-line" id="name" placeholder="">
                            </div>
                            <div class="col-sm-4 form-group">
                                <label for="duration" class="control-label">Duration (in Days)</label>
                                <input type="number" name="duration" value="<?php if (isset($rowData['duration'])) { echo $rowData['duration']; }else{ echo set_value('duration'); } ?>" class="form-control" id="duration" placeholder="">
                            </div>
                            <!-- <div class="col-sm-4 form-group">
                                <label for="role" class="control-label">Status</label>
                                <select name="isActive" class="form-control">
                                    <option value="">Select Status</option>
                                    <option value="1" <?php
                                    if (isset($rowData['isActive']) && $rowData['isActive'] == '1') {
                                        echo 'selected';
                                    } ?>> Active </option>
                                    <option value="0" <?php
                                    if (isset($rowData['isActive']) && $rowData['isActive'] == '0') {
                                        echo 'selected';
                                    } ?>> Inactive </option>
                                </select>
                            </div> -->
                            <div class="col-sm-12 form-group">
                                <input type="submit" name="submit" value="Save" class="btn btn-info" />
                                <a href="<?= base_url('class'); ?>" class="btn btn-danger"> Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
;(function ($, window, document, undefined) {
$('document').ready(function () {
    $('#startdate').bootstrapMaterialDatePicker({
        format: 'DD-MM-YYYY',
        time: false,
        date: true
    });
});
})(jQuery, window, document);
;(function ($, window, document, undefined) {
$('document').ready(function () {
    $('#enddate').bootstrapMaterialDatePicker({
        format: 'DD-MM-YYYY',
        time: false,
        date: true
    });
});
})(jQuery, window, document);
</script> 

