<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body bg-info">
                <h4 class="text-white card-title">
                <a class="btn btn-info" href="<?= base_url('class/add'); ?>"><i class="fa fa-plus"></i> Add</a> &nbsp; &nbsp; &nbsp; 
                    Activity List
                </h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
								<th>Start Date</th>
								<th>End Date</th>
                                <th>Name</th>
                                <th>Duration (In Days)</th>
                                <th>Status</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($resultList)) {
                                foreach ($resultList as $key => $row) : ?>
                                    <tr  id="lnr_<?= $row['classID']; ?>">
                                        <td><?= $row['classID']; ?></td>
										<td><?= (isset($row['startdate'])) ? $row['startdate'] : "-"; ?></td>
										<td><?= (isset($row['enddate'])) ? $row['enddate'] : "-"; ?></td>
										
                                        <td><?= (isset($row['name'])) ? $row['name'] : "-"; ?></td>
                                        <td><?= (isset($row['duration'])) ? $row['duration'] : "-"; ?></td>
                                        <td><?php 
                                            if($row['isActive'] == 1){?>
                                                <span class="btn btn-primary btn-flat btn-xs" onclick="inactive(<?= $row['classID'] ?>)" id="active_<?= $row['classID'] ?>" >Active</span>
                                                <span class="btn btn-danger btn-flat btn-xs hidden" style="display:none;" onclick="active(<?= $row['classID'] ?>)" id="inactive_<?= $row['classID'] ?>">Inactive</span>
                                        <?php }else{ ?> 
                                                <span class="btn btn-danger btn-flat btn-xs" onclick="active(<?= $row['classID'] ?>)" id="inactive_<?= $row['classID'] ?>">Inactive</span>
                                                <span class="btn btn-primary btn-flat btn-xs " style="display:none;" onclick="inactive(<?= $row['classID'] ?>)" id="active_<?= $row['classID'] ?>">Active</span>
                                        <?php } ?>
                                        </td>
                                        <!-- <td><?php // echo (isset($row['isActive']) && $row['isActive'] == 1) ? "Active" : "Inactive"; ?> </td> -->
                                        <td class="">
                                            <a href="<?= base_url('class/edit/' . $row['classID']); ?>" class="btn btn-info btn-sm "><i class="fa fa-edit"></i></a>
                                            <span  onclick="deletedata('<?= $row['classID']; ?>');" class="btn btn-sm btn-danger "><i class="fa fa-trash"></i></span>
                                        </td>
                                    </tr>
                                <?php endforeach;
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> 

<script>
;(function ($, window, document, undefined) {
    $('document').ready(function () {

    });
})(jQuery, window, document);

function deletedata(classid) {
  var r = confirm("Are you sure delete this data!");
  if (r == true) {
    $.ajax({
        type: "POST",
        url: "<?php echo base_url('class/delete') ?>",
        data:{classid:classid},
        success: function(data){
            if(data)
            {
                $('#lnr_'+classid).hide();
            }
        }
    });
  } 
}

function active(classid){
    // var classid = $('#classid').val();
    //alert(classid);
    $.ajax({
        type: "POST",
        url: "<?php echo base_url('dashboard/classIsactive') ?>",
        data:{status:1,classid:classid},
        success: function(data){
            if(data)
            {
                $('#active_'+classid).show();
                $('#inactive_'+classid).hide();
            }
        }
    });
}

function inactive(classid){
    $.ajax({
        type: "POST",
        url: "<?php echo base_url('dashboard/classIsactive') ?>",
        data:{status:0,classid:classid},
        success: function(data){
            if(data)
            {
                $('#inactive_'+classid).show();
                $('#active_'+classid).hide();
            }
        }
    });
}
</script>