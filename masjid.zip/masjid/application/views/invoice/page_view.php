<?php
//echo "<pre>"; print_r($user); echo "</pre>";
?>
<div class="row">
    <!-- Column -->
    <div class="col-lg-4 col-md-6">

        <div class="ribbon-wrapper card">
            <div class="ribbon ribbon-bookmark  ribbon-default">USER</div>
            <center class="">
                <?php if(!empty($user['picture'])){ ?>
                    <img src="<?php echo base_url(PROFILE.$user['picture']); ?>" class="img-circle" width="150" />
                <?php } ?>
                <h4 class="card-title m-t-10"><?php echo ($user['name']) ? $user['name'] : "" ?></h4>
            </center>
            <div>
                <hr>
            </div>
            <div class="card-body">
                <h6 class="text-muted"><b>Email</b> : <?php echo ($user['email']) ? $user['email'] : "" ?></h6>
                <hr>
                <h6 class="text-muted"><b>Phone Number</b> : <?php echo ($user['mobile']) ? $user['mobile'] : "" ?></h6>
                <hr>
                <h6 class="text-muted"><b>Gender</b> : <?php echo ($user['gender']) ? $user['gender'] : "" ?></h6>
                <hr>
                <h6 class="text-muted"><b>Date of Birth</b> : <?php echo ($user['dob']) ? $user['dob'] : "" ?></h6>
            </div>
        </div>
    </div>
    <!-- Column -->

    <!-- <div class="col-lg-4 col-md-6">
        <div class="card">
            <div class="card-body bg-info">
                <h4 class="text-white card-title">Friends</h4>
               <h6 class="card-subtitle text-white m-b-0 op-5">Checkout friends list here</h6> 
            </div>

            <div class="card-body" style="padding:0.5em;">
                <div class="message-box contact-box">
                    <table id="example1" class="table">
                        <thead>
                            <tr>
                                <th>Profile</th>
                                <th>Name</th>
                            </tr>
                        </thead>
                     
                    </table>
                </div>
            </div>
        </div>
    </div> -->

    <!-- Column -->
</div>



<script>
    // $("#view_user").addClass('active');
    $(function() {
        $('#example').DataTable();
        $('#example1').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "pageLength": 5,
            //"bFilter": false,
            "bInfo": false
        });
    });
</script>