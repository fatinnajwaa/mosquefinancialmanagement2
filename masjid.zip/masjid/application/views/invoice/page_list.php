<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body bg-info">
                <h4 class="text-white card-title">
                <a class="btn btn-info" href="<?= base_url('invoice/add'); ?>"><i class="fa fa-plus"></i> Add</a>
                    &nbsp; &nbsp; Invoice List
                    <div class="pull-right">
                        <h4 class="card-title"></h4>
                    </div>
                </h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <!-- <th>#ID</th> -->
                                <th style="width: 80px;">Date</th>
                                <th>Membership</th>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Type</th>
                                <th>Activity</th>
                                <th>Address</th>
                                <th>Employee</th>
                                <th>Reference Number</th>
                                <th>Amount </th>
                                <th>Branch</th>
                                <?php $userRole = $this->session->userdata('user_type');
                                    if($userRole == 3){ ?>
                                <th>Action</th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($resultList)) {
                                foreach ($resultList as $key => $row) : 
                                    $type = (isset($row['type'])) ? $this->Service->getTypeName(explode(',',$row['type']),true) : "-";
                                    // echo '<pre>';print_r($type);die;
                                    $employeeName = $this->Service->getEmployeeName(explode(',',$row['employeeID']),true);
                                    $class = "class";
                                    $inTime = (isset($row['inTime'])) ? $row['inTime'] : "00:00";
                                    $outTime = (isset($row['outTime'])) ? $row['outTime'] : "00:00";
                                    ?>
                                    <tr id="lnr_<?= $row['invoiceID']; ?>">
                                        <!-- <td><?= $row['invoiceID']; ?></td> -->
                                        <td><?= (isset($row['invoiceDate'])) ? date('d-m-Y',strtotime( $row['invoiceDate'])) : "-"; ?></td>
                                        <td><?= (isset($row['membershipID']) && $row['membershipID']!="") ? $row['membershipID'] : "PAYEE"; ?></td>
                                        <td><?= (isset($row['customerName'])) ? $row['customerName'] : "-"; ?></td>
                                        <td><?= (isset($row['customerMobile'])) ? $row['customerMobile'] : "-"; ?></td>
                                        <td><?php foreach($type as $pro){
                                            echo $pro['name'] .'<br>';
                                        } ?></td>
                                        <td class="uppercaseFont"><?= (isset($row['classID'])) ? $this->Service->getclassName($row['classID']) : "-"; ?></td>
                                        
                                        <td><?= (isset($row['address'])) ? $row['address'] : "-"; ?></td>
                                        
                                       
                                        <td class="uppercaseFont">
                                            <?php
                                            if(!empty($employeeName)){
                                                foreach($employeeName as $empe){
                                                    echo $empe['name']  .'<br>';
                                                }
                                            }
                                            (isset($row['employeeID'])) ?   : "-"; ?>
                                        </td>
                                        <td>
                                            <?= (isset($row['yslip'])) ? $row['yslip'] : "-"; ?>
                                        </td>
                                        <td><?= (!empty($row['amount']) && $row['amount'] != '0') ? $row['amount'].'<i class="mdi mdi-currency-myr"></i>' : '<span class="label label-danger font-weight-100">MEMBER</span>' ; ?>
                                        <?php if(isset($row['payMode']) && $row['payMode']!="" && $row['amount']!=0){ ?><br><label class="label label-info"><?= (isset($row['payMode'])) ? $row['payMode'] : ""; ?></label><?php } ?></td>
                                        <td><?= (isset($row['managerID'])) ? $this->Service->getBranceName($row['managerID']) : "-"; ?></td>
                                        
                                        <?php $userRole = $this->session->userdata('user_type');
                                        if($userRole == 3){ ?>
                                            <td class="">
                                                <?php  
                                                if(isset($_GET['branch']) && $_GET['branch'] != ''){
                                                    $url = base_url('invoice/edit/' . $row['invoiceID'].'?branch='.$_GET['branch']);
                                                }else{
                                                    $url = base_url('invoice/edit/' . $row['invoiceID']);
                                                }  ?>
                                                <a href="<?= $url; ?>" class="btn btn-info btn-sm "><i class="fa fa-edit"></i></a>
                                                <span  onclick="deletedata('<?= $row['invoiceID']; ?>');" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></span>
                                            </td>
                                        <?php } ?>
                                    </tr>
                                <?php endforeach;
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> 

<script>
;(function ($, window, document, undefined) {
    $('document').ready(function () {

    });
})(jQuery, window, document);

function deletedata(expid) {
//   alert(expid);
  var r = confirm("Are you sure delete this data!");
  if (r == true) {
    $.ajax({
        type: "POST",
        url: "<?php echo base_url('invoice/delete') ?>",
        data:{expid:expid},
        success: function(data){
            if(data)
            {
                $('#lnr_'+expid).hide();
            }
        }
    });
  } 
}

</script>