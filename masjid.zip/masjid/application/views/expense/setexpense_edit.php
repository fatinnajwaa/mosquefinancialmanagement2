<section class="content">

    <div class="row">

        <div class="col-md-12">

            <div class="card">
                <div class="card-body bg-info">
                    <h4 class="text-white card-title">
                        Expense Value
                    </h4>
                </div>
                <div class="card-body">

                    <div class="box-body my-form-body">
                        
                        <form class="row" action="<?php echo base_url('expense/setExpense'); ?>" class="" method="post" enctype="multipart/form-data">
                            <div class="col-sm-2 form-group">
                                <label for="pdm" class=" control-label">Cleaning Services inside Mosque/Surau (RM):</label>
                                <input type="number" name="pdm" value="<?php if (isset($resultList['pdm'])) { echo $resultList['pdm'];}else{ echo set_value('pdm'); } ?>" class="form-control form-control-line" id="expense" expenseholder="">
                            </div>
							
						<div class="col-sm-2 form-group">
                                <label for="plm" class=" control-label">Cleaning Services outside Mosque/Surau (RM) :</label>
                                <input type="number" name="plm" value="<?php if (isset($resultList['plm'])) { echo $resultList['plm'];}else{ echo set_value('plm'); } ?>" class="form-control form-control-line" id="expense" expenseholder="">
                            </div>
                            
                            
                            <div class="col-sm-2 form-group">
                                <label for="pt" class=" control-label"> Toilet Cleaning (RM) :</label>
                                <input type="number" name="pt" value="<?php if (isset($resultList['pt'])) { echo $resultList['pt'];}else{ echo set_value('pt'); } ?>" class="form-control form-control-line" id="lat" expenseholder="">
                             </div>

                            <div class="col-sm-2 form-group">
                                <label for="karpet" class=" control-label"> Carpet (RM) : </label>
                                <input type="number" name="karpet" value="<?php if (isset($resultList['karpet'])) { echo $resultList['karpet'];}else{ echo set_value('karpet'); } ?>" class="form-control form-control-line" id="lat" expenseholder="">
                            </div>

                            <div class="col-sm-2 form-group">
                                <label for="telekung" class="control-label"> Women Prayer Veil (RM) : </label>
                                <input type="number" name="telekung" value="<?php if (isset($resultList['telekung'])) { echo $resultList['telekung'];}else{ echo set_value('telekung'); } ?>" class="form-control form-control-line" id="lang" expenseholder="">
                             </div>
                            
                            <div class="col-sm-2 form-group">
                                <label for="sanitizer" class=" control-label"> Hand Sanitizer (RM) :</label>
                                <input type="number" name="sanitizer" value="<?php if (isset($resultList['sanitizer'])) { echo $resultList['sanitizer'];}else{ echo set_value('sanitizer'); } ?>" class="form-control form-control-line" id="sanitizer" expenseholder="">
                             </div>
                            <div class="col-sm-2 form-group">
                                <label for="sejadah" class=" control-label">Sajadah (RM) :</label>
                                <input type="number" name="sejadah" value="<?php if (isset($resultList['sejadah'])) { echo $resultList['sejadah'];}else{ echo set_value('sejadah'); } ?>" class="form-control form-control-line" id="sejadah" expenseholder="">
                             </div>
                            <div class="col-sm-2 form-group">
                                <label for="langsir" class=" control-label">Curtains (RM) :</label>
                                <input type="number" name="langsir" value="<?php if (isset($resultList['langsir'])) { echo $resultList['langsir'];}else{ echo set_value('langsir'); } ?>" class="form-control form-control-line" id="langsir" expenseholder="">
                            </div>

                            <div class="col-sm-12 form-group">
                                <div class="">
                                    <!-- <input type="hidden" name="<?php //echo $this->security->get_csrf_token_name();     ?>" value="<?php //echo $this->security->get_csrf_hash();     ?>">-->
                                    <input type="submit" name="submit" value="Update" class="btn btn-info" />
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 

<script>
;(function ($, window, document, undefined) {
    $('document').ready(function () {
        
        if (window.File && window.FileList && window.FileReader) {
            $("#upload").on("change", function(e) {
                var files = e.target.files,
                    filesLength = files.length;

                for (var i = 0; i < filesLength; i++) {
                    var f = files[i]
                    var fileReader = new FileReader();
                    fileReader.onload = (function(e) {
                        var file = e.target;
                        var menuName = '';
                        var newHtml = '<div class="pimg col-md-2 number-center ">' +
                            // '<input type="hidden" name="picture[]" value="' + e.target.result + '" />' +
                            '<div class="" style="background: url(' + e.target.result + ');  background-position: center;background-size: contain;background-repeat: no-repeat;height: 150px;"></div>' +
                            //"<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
                            '<span class="removeportfolio btn btn-danger btn-sm"> Remove </span>' +
                            '</div>';
                        $('#portfolioSection').html(newHtml);

                        $(".removeportfolio").click(function() {
                            $(this).parent(".pimg").remove();
                        });
                    });
                    fileReader.readAsDataURL(f);
                }
            });
            $(".removeportfolio").click(function() {
                $(this).parent(".pimg").remove();
            });
        } else {
            alert("Your browser doesn't support to File API")
        }
    });
})(jQuery, window, document);
</script> 

