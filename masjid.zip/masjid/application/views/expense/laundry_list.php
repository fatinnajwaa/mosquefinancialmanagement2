<div class="row">

    <div class="col-12">

        <div class="card">
            <div class="card-body bg-info">
                <h4 class="text-white card-title">
                <a class="btn btn-info" href="<?= base_url('expense/laundry/add'); ?>"><i class="fa fa-plus"></i> Add</a>&nbsp; &nbsp; &nbsp;
                    Laundry Expenses List
                </h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <!-- <th>ID</th> -->
                                <th style="width: 50px;">No</th>
                                <th>Date</th>
                                <th>Carpet</th>
                                <th>Women Prayer Veil</th>
                                <th>Hand Sanitizer</th>
                                <th>Sajadah</th>
                                <th>Curtains</th>
                                <th style="width: 70px;">Amount</th>
                                <th style="width: 100px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($resultList)) {
                                foreach ($resultList as  $key => $row) : ?>
                                    <tr id="lnr_<?= $row['expenseID']; ?>">
                                        <td><?= $key+1; ?></td>
                                        <td ><?= isset($row['date']) ? $this->Service->dateFormating($row['date']) :''; ?></td>
                                        <td class="">
                                            <?= isset($row['karpet']) ? "<i class='mdi mdi-currency-myr'></i>".''. ($expValue['karpet'] * $row['karpet']).' ('.($row["karpet"]).')':'' ?>
                                        </td>
                                        <td ><?= isset($row['telekung']) ? "<i class='mdi mdi-currency-myr'></i>".''. ($expValue['telekung'] * $row['telekung']).' ('.($row["telekung"]).')':'' ?></td>
                                        <td ><?= isset($row['sanitizer']) ? "<i class='mdi mdi-currency-myr'></i>".''. ($expValue['sanitizer'] * $row['sanitizer']).' ('.($row["sanitizer"]).')':'' ?></td>
                                        <td ><?= isset($row['sejadah']) ? "<i class='mdi mdi-currency-myr'></i>".''. ($expValue['sejadah'] * $row['sejadah']).' ('.($row["sejadah"]).')':'' ?></td>
                                        <td ><?= isset($row['langsir']) ? "<i class='mdi mdi-currency-myr'></i>".''. ($expValue['langsir'] * $row['langsir']).' ('.($row["langsir"]).')':'' ?></td>
                                        <td ><i class="mdi mdi-currency-myr"></i><?= (isset($row['total'])) ? $row['total'] : "-"; ?></td>
                                        <td class="">
                                            <span onclick="deletedata('<?= $row['expenseID']; ?>');" class="btn btn-sm btn-danger "><i class="fa fa-trash"></i></span>
                                            <a href="<?= base_url('expense/laundry/edit/' . $row['expenseID']); ?>" class="btn btn-sm btn-info"><i class="fa fas fa-pencil-alt"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach;
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> 

<script>
;(function ($, window, document, undefined) {
    $('document').ready(function () {
        $('#mdate').bootstrapMaterialDatePicker({
            format: 'YYYY-MM-DD',
            time: false,
            date: true
        });
    });
})(jQuery, window, document);

function deletedata(expid) {
//   alert(expid);
  var r = confirm("Are you sure delete this data!");
  if (r == true) {
    $.ajax({
        type: "POST",
        url: "<?php echo base_url('expense/laundry/delete') ?>",
        data:{expid:expid},
        success: function(data){
            if(data)
            {
                $('#lnr_'+expid).hide();
            }
        }
    });
  } 
}

</script>
