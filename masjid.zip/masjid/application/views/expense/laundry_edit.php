<section class="content">

    <div class="row">

        <div class="col-md-12">

            <div class="card">
                <div class="card-body bg-info">
                    <h4 class="text-white card-title">
                    Laundry Expense
                    </h4>
                </div>

                <div class="card-body">

                    <div class="box-body my-form-body">
                        <?php if(!empty($rowData) && $rowData['expenseID'] !='' ){
                            $action = base_url('expense/laundry/edit/'.$rowData['expenseID']);
                        }else{
                            $action = base_url('expense/laundry/add');
                        } ?>
                        
                        <form class="row" action="<?php echo $action; ?>" class="" method="post" enctype="multipart/form-data">
                            <div class="col-sm-2 form-group">
                                <label for="date" class=" control-label">Date:</label>
                                <div class="input-group">
                                    <input type="text" name="date" class="form-control datePicker" value="<?php if (isset($rowData['date'])) { echo $rowData['date'];}else{ echo date('d-m-Y'); } ?>" placeholder="<?= date('d-m-Y'); ?>" id="mdate">
                                    <div class="input-group-append">
                                        <button class="btn btn-info" type="button"><i class="icon-calender"></i></button>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-2 form-group">
                                <label for="karpet" class=" control-label"> Carpet: </label>
                                <input type="number" name="karpet" value="<?php if (isset($rowData['karpet'])) { echo $rowData['karpet'];}else{ echo set_value('karpet'); } ?>" class="form-control form-control-line" id="karpet" expenseholder="">
                             </div>

                            <div class="col-sm-2 form-group">
                                <label for="telekung" class=" control-label"> Women prayer veil:</label>
                                <input type="number" name="telekung" value="<?php if (isset($rowData['telekung'])) { echo $rowData['telekung'];}else{ echo set_value('telekung'); } ?>" class="form-control form-control-line" id="telekung" expenseholder="">
                            </div>

                            <div class="col-sm-2 form-group">
                                <label for="sanitizer" class="control-label"> Hand Sanitizer: </label>
                                <input type="number" name="sanitizer" value="<?php if (isset($rowData['sanitizer'])) { echo $rowData['sanitizer'];}else{ echo set_value('sanitizer'); } ?>" class="form-control form-control-line" id="lang" expenseholder="">
                             </div>

                            <div class="col-sm-2 form-group">
                                <label for="sejadah" class="control-label"> Sajadah:  </label>
                                <input type="number" name="sejadah" value="<?php if (isset($rowData['sejadah'])) { echo $rowData['sejadah'];}else{ echo set_value('sejadah'); } ?>" class="form-control form-control-line" id="lang" expenseholder="">
                             </div>

                            <div class="col-sm-2 form-group">
                                <label for="langsir" class="control-label"> Curtains: </label>
                                <input type="number" name="langsir" value="<?php if (isset($rowData['langsir'])) { echo $rowData['langsir'];}else{ echo set_value('langsir'); } ?>" class="form-control form-control-line" id="lang" expenseholder="">
                             </div>
                            
                            <div class="col-sm-12 form-group">
                                <div class="">
                                    <input type="submit" name="submit" value="Save" class="btn btn-info" />
                                    <a href="<?= base_url('expense/laundry'); ?>" class="btn btn-danger">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 

<script>
;(function ($, window, document, undefined) {
    $('document').ready(function () {
        $('.datePicker').datepicker({
            format: 'd-m-yyyy',
        });
    });
})(jQuery, window, document);
</script> 

