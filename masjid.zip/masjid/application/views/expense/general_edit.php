<section class="content">

    <div class="row">

        <div class="col-md-12">

            <div class="card">
                <div class="card-body bg-info">
                    <h4 class="text-white card-title">
                    General Expense
                    </h4>
                </div>

                <div class="card-body">

                    <div class="box-body my-form-body">
                        <?php if(!empty($rowData) && $rowData['genExpID'] !='' ){
                            $action = base_url('expense/general/edit/'.$rowData['genExpID']);
                        }else{
                            $action = base_url('expense/general/add');
                        } ?>
                        
                        <form class="row" action="<?php echo $action; ?>" class="" method="post" enctype="multipart/form-data">
                            <div class="col-sm-3 form-group">
                                <label for="date" class=" control-label">Date:</label>
                                <div class="input-group">
                                    <input type="text" name="date" class="form-control datePicker" value="<?php if (isset($rowData['date'])) { echo $rowData['date'];}else{ echo date('d-m-Y'); } ?>" placeholder="<?= date('d-m-Y'); ?>" id="mdate">
                                    <div class="input-group-append">
                                        <button class="btn btn-info" type="button"><i class="icon-calender"></i></button>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3 form-group">
                                <label for="pdm" class=" control-label"> Cleaning Services inside Mosque/Surau :</label>
                                <input type="number" name="pdm" value="<?php if (isset($rowData['pdm'])) { echo $rowData['pdm'];}else{ echo set_value('pdm'); } ?>" class="form-control form-control-line" id="lat" expenseholder="">
                             </div>

                            <div class="col-sm-3 form-group">
                                <label for="plm" class=" control-label"> Cleaning Services outside Mosqu/Surau:</label>
                                <input type="number" name="plm" value="<?php if (isset($rowData['plm'])) { echo $rowData['plm'];}else{ echo set_value('plm'); } ?>" class="form-control form-control-line" id="lat" expenseholder="">
                            </div>

                            <div class="col-sm-3 form-group">
                                <label for="pt" class="control-label"> Toilet Cleaning : </label>
                                <input type="number" name="pt" value="<?php if (isset($rowData['pt'])) { echo $rowData['pt'];}else{ echo set_value('pt'); } ?>" class="form-control form-control-line" id="lang" expenseholder="">
                             </div>
                            
                            <div class="col-sm-12 form-group">
                                <div class="">
                                    <input type="submit" name="submit" value="Save" class="btn btn-info" />
                                    <a href="<?= base_url('expense/general'); ?>" class="btn btn-danger">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 

<script>
;(function ($, window, document, undefined) {
    $('document').ready(function () {
        // $('#mdate').bootstrapMaterialDatePicker({format: 'DD-MM-YYYY', weekStart: 0, time: false });
        $('.datePicker').datepicker({
            format: 'd-m-yyyy',
        });
    });
})(jQuery, window, document);
</script> 

